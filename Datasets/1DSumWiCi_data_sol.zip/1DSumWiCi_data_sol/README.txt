(open with a markdown editor for a better view.)
#### Introduction

Current folder contains the benchmark datasets and corresponding optimal solution values of the 1|d_i^{\tilde}|\sum{w_iC_i} problem. 
The technique of *Memorization* allows to solve optimally instances with up to 130 jobs for the first dataset and 110 for the second dataset. 
The algorithm of Tanaka et al. 2009 allows to solve optimally instances with up to 130 jobs for the first dataset and 100 jobs for the second dataset.


The test environment is as follows:

- Time limit: 5h
- Machine: HP Z400 work station with Intel Xeon W3550 3.07GHz CPU and 8GB RAM
- System: Windows 7 64bits SP1

References are

- L. Shang, V. T 'Kindt, F. Della Croce. The Memorization Paradigm: Branch & Memorize Algorithms for the Efficient Solution of Sequencing Problems. HAL 〈hal-01599835〉. 2017.
- S. Tanaka, S. Fujikuma, M. Araki (2009). An exact algorithm for single-machine scheduling without machine idle time. Journal of Scheduling, 12(6), 575-593.

To get the related code or other information, contact *tkindt@univ-tours.fr*.

To get benchmark datasets of some other scheduling problems, check http://vincent-tkindt.net/index.php/resources.

#### Generation

For each job i, its processing time p_i is an integer generated randomly from the uniform distribution [1,Pmax] and its weight w_i is generated uniformly from [1,Wmax]. The total processing time P is then computed and for each job i an integer deadline d_i is generated from the uniform distribution [P(L - R/2); P(L + R/2)], with (L,R) in {(0.6,1.0),(0.6,1.2),(0.6,1.4),(0.7,0.8),(0.7,1.0),(0.7,1.2),(0.7,1.4),(0.8,0.4),(0.8,0.6),(0.8,0.8),(0.8,1.0),(0.8,1.2),(0.8,1.4),(0.9,0.2),(0.9,0.4),(0.9,0.6),(0.9,0.8),(0.9,1.0),(0.9,1.2),(0.9,1.4)}.
For each of which, 10 feasible instances are generated, yielding a total of 200 instances for each value of n. 

Two datasets were generated:
- with Pmax=100, Wmax=10
- with Pmax=1000, Wmax=100

#### File Format

Each file corresponds to one instance. As an example, instance ./40/SDT_40_0.9_1.4_9.dat is an instance of 40 jobs, generated with l=0.9, r=1.4 and its id is 9.

Each line in the file contains 5 integers of which only the first 4 are used: the job id, the job weight, the processing time and the deadline. 

#### Solutions

Optimal solution values can be found in sol folder.